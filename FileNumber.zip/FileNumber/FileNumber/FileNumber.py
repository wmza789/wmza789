import os

filedict = {} # Declare dictionary
for root, dirs, files in os.walk(input("Enter directory path: ")):
    for filename in files: # loop each file within directory
        with open(os.path.abspath(os.path.join(root, filename))) as file: # get full path of file to open file
            # stores filename and content in dictionary
            # with filename stored as key and integer value of first line in file stored as value
            filedict[filename[0:filename.rindex(".")]] = int(file.readline())
filenamesorted = sorted(filedict.keys(), key=filedict.get) # returns array of filenames[keys] sorted by value
for filename in filenamesorted:
    print(filename, end="") # prints filenames without newlines
print() # prints newline